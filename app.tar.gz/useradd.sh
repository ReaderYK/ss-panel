#!/bin/sh
clear
echo "是否显示当前已存在帐号<不输入回车默认将不显示已存在帐号>"
echo -e -n "[输入y/n]：" 
read yn
if [ "$yn" = "y" ];then
cat /etc/openvpn/passwd.txt 
fi
echo
echo "选择一项继续执行"
echo "1.添加一个新帐号"
echo "2.删除一个已经添加的帐号"
echo "3.退出脚本"
echo -e -n "[输入 1/2/3] 单选 ？：" 
read add
echo
if [ "$add" = "1" ];then
echo "添加帐号 <不输入回车将退出脚本>"
echo -e -n "[输入]：" 
read user
echo "设置密码 <不输入回车将退出脚本>"
echo -e -n "[输入]：" 
read passwd
echo -e "添加帐号密码到配置文件"
echo "$user $passwd" >>/etc/openvpn/passwd.txt
echo "添加完成"
service openvpn restart
exit
fi
echo
if [ "$add" = "2" ];then
echo "输入需要删除的帐号 <不输入回车将退出脚本>"
echo -n "[输入]："
read rmuser
if [[ -z $rmuser ]];then
exit
else
sed -i '/'"$rmuser"'/d' /etc/openvpn/passwd.txt
echo "已删除帐号$rmuser"
service openvpn restart
fi
fi 
if [ "$add" = "3" ];then
echo "退出脚本"
exit 
fi 
exit 